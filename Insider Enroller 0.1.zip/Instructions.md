**Run Registry Files First**
These files contain registry values to enable TPM Check Bypass for Windows 11 Update
and For Enabling Preview Builds

**Open Insider-Enroller 1.0.0 Folder and Run Insider Enroller.cmd file as Administrator**
this is the important file please read Insider Enroller 1.0.0\readme.md" for further instruction

**Thank you for Using my script Enjoy your preview builds**